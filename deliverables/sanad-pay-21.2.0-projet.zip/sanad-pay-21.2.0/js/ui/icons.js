'use strict';

/* ============================================================
   SVG ICONS
   ============================================================ */
const IC = {
  home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  history:'<path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5"/><path d="M12 8v4l3 2"/>',
  send:'<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7Z"/>',
  receive:'<path d="M12 5v14M5 12l7 7 7-7"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  minus:'<path d="M5 12h14"/>',
  close:'<path d="M6 6l12 12M18 6l-12 12"/>',
  check:'<path d="M5 12l5 5L20 7"/>',
  chev:'<path d="M9 6l6 6-6 6"/>',
  back:'<path d="M15 18l-6-6 6-6"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/>',
  wallet:'<path d="M3 7a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2v3M3 7v11a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-6M3 7h16M20 13h-3a2 2 0 0 0 0 4h3"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/>',
  cards:'<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M2 10h20"/>',
  crypto:'<circle cx="12" cy="12" r="9"/><path d="M9 9h4a2 2 0 0 1 0 4H9v2h4M11 7v2M11 15v2"/>',
  mobile:'<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  profile:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  shield:'<path d="M12 3l8 4v6c0 5-3.5 8-8 8s-8-3-8-8V7l8-4z"/><path d="M9 12l2 2 4-4"/>',
  eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff:'<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22"/><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/>',
  bell:'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
  chart:'<path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/>',
  trending:'<path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/>',
  share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
  download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M3 10h18M8 2v4M16 2v4"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
  doc:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
  percent:'<circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/><path d="M19 5L5 19"/>',
  logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
  warn:'<path d="M12 3l10 18H2L12 3zM12 10v5M12 18h.01"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  swap:'<path d="M7 4v13M7 4l-3 3M7 4l3 3M17 20V7M17 20l-3-3M17 20l3-3"/>',
  bank:'<path d="M3 10l9-6 9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 21h18"/>',
  banknote:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
  qr:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3M21 14v7M14 21h7"/>',
  network:'<circle cx="12" cy="12" r="3"/><circle cx="5" cy="5" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 6.5l3 3M14 6.5l-3 3M7 17.5l3-3M14 17.5l-3-3"/>',
  arrowRight:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  arrowUpRight:'<path d="M7 17L17 7M7 7h10v10"/>',
  arrowDownRight:'<path d="M7 7l10 10M17 7v10H7"/>',
  sparkle:'<path d="M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M5 19l4-4M15 9l4-4"/>',
  trash:'<path d="M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 16v-5M12 8h.01"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.6 2.2c-.7.4-1.1.9-1.1 1.8M12 17h.01"/>',
  vibrate:'<rect x="8" y="3" width="8" height="18" rx="2"/><path d="M3 8v8M21 8v8"/>',
  contact:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/><circle cx="19" cy="6" r="2.5" fill="currentColor" stroke="none"/>',
  device:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>',
  session:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>'
};
/* ============================================================
   Sanad Pay 21.0.0 — jeu d'icônes « Horizon » : trait uniforme sur grille 48 (pack de marque : icons/svg, trait 2,6 -> 3,6 pour la lisibilité à 20-24 px),
   bouts ronds, AUCUNE ombre décalée (l'ancien jeu duotone .d2 de Freindi Pay n'est plus dessiné). Les icônes absentes du pack sont redessinées sur la même
   grille ; les anciens tracés 24 px encore utilisés par des modules secondaires sont redimensionnés (x2) au même trait, sans leur ombre.
   ============================================================ */
const SXI = {
  home:'<path d="m5 22 19-16 19 16v20H5Z"/><path d="M18 42V27h12v15"/>',
  history:'<path d="M8 14A19 19 0 1 1 6 29M8 6v10H18M24 13v12l9 5"/>',
  cards:'<rect x="5" y="10" width="38" height="28" rx="6"/><path d="M5 20h38M12 30h9"/>',
  send:'<path d="M43 5 5 20l15 7 7 15Z"/><path d="M43 5 20 27"/>',
  receive:'<path d="M24 6v29m-12-12 12 12 12-12M8 42h32"/>',
  plus:'<path d="M24 10v28M10 24h28"/>',
  minus:'<path d="M10 24h28"/>',
  close:'<path d="m13 13 22 22m0-22L13 35"/>',
  check:'<path d="m10 25 10 10 18-21"/>',
  checkCircle:'<circle cx="24" cy="24" r="19"/><path d="m13 24 8 8 15-17"/>',
  chev:'<path d="m18 9 15 15-15 15"/>',
  back:'<path d="M30 9 15 24l15 15"/>',
  user:'<circle cx="24" cy="17" r="10"/><path d="M6 44c0-13 8-20 18-20s18 7 18 20"/>',
  profile:'<circle cx="24" cy="17" r="10"/><path d="M6 44c0-13 8-20 18-20s18 7 18 20"/>',
  wallet:'<rect x="5" y="9" width="38" height="30" rx="7"/><path d="M31 19h12v12H31a6 6 0 0 1 0-12Z"/>',
  globe:'<circle cx="24" cy="24" r="20"/><path d="M4 24h40M24 4a36 36 0 0 0 0 40M24 4a36 36 0 0 1 0 40"/>',
  crypto:'<circle cx="24" cy="24" r="19"/><path d="M24 9v30M16 14h12a7 7 0 0 1 0 14H16h13a7 7 0 0 1 0 14H16"/>',
  mobile:'<rect x="13" y="3" width="22" height="42" rx="5"/><path d="M21 39h6"/>',
  device:'<rect x="13" y="3" width="22" height="42" rx="5"/><path d="M21 39h6"/>',
  settings:'<circle cx="24" cy="24" r="7"/><path d="M19 5h10l2 7 6 3 6-3 5 9-6 5v5l6 5-5 8-7-2-5 3-2 7H19l-2-7-5-3-7 2-5-8 6-5v-5l-6-5 5-9 7 3 5-3Z"/>',
  lock:'<rect x="8" y="20" width="32" height="24" rx="5"/><path d="M15 20v-7a9 9 0 0 1 18 0v7"/>',
  shield:'<path d="m24 5 17 7v13c0 11-7 18-17 22C14 43 7 36 7 25V12Z"/><path d="m16 26 6 6 12-13"/>',
  eye:'<path d="M3 24c10-16 32-16 42 0-10 16-32 16-42 0Z"/><circle cx="24" cy="24" r="6"/>',
  eyeOff:'<path d="M3 24c10-16 32-16 42 0-10 16-32 16-42 0Z"/><circle cx="24" cy="24" r="6"/><path d="M8 40 40 8"/>',
  bell:'<path d="M11 35h26l-4-7v-9a9 9 0 0 0-18 0v9Z"/><path d="M20 40a4 4 0 0 0 8 0"/>',
  download:'<path d="M24 5v30m-12-12 12 12 12-12M7 36v7h34v-7"/>',
  upload:'<path d="M24 35V5M12 17 24 5l12 12M7 33v9h34v-9"/>',
  qr:'<path d="M5 5h14v14H5ZM29 5h14v14H29ZM5 29h14v14H5ZM29 29h6v6h-6ZM37 37h6v6h-6ZM37 29h6"/>',
  search:'<circle cx="21" cy="21" r="14"/><path d="m32 32 12 12"/>',
  bank:'<path d="m4 19 20-12 20 12ZM8 22v19M18 22v19M30 22v19M40 22v19M4 42h40"/>',
  doc:'<path d="M11 4h26v40l-6-4-7 4-7-4-6 4Z"/><path d="M17 15h14M17 23h14M17 31h9"/>',
  bill:'<path d="M10 4h28v40l-7-4-7 4-7-4-7 4Z"/><path d="M17 15h14M17 23h14M17 31h10"/>',
  cal:'<rect x="5" y="10" width="38" height="33" rx="5"/><path d="M5 20h38M15 5v10M33 5v10"/>',
  swap:'<path d="M7 16h33M32 8l8 8-8 8M41 34H8m8-8-8 8 8 8"/>',
  logout:'<path d="M20 7H7v34h13M16 24h27m-10-9 10 9-10 9"/>',
  arrowRight:'<path d="M10 24h28M25 11l13 13-13 13"/>',
  arrowLeft:'<path d="M38 24H10m13-13L10 24l13 13"/>',
  help:'<path d="M7 26V22a17 17 0 0 1 34 0v4M7 26h8v13H9a5 5 0 0 1-5-5v-3a5 5 0 0 1 3-5Zm34 0h-8v13h6a5 5 0 0 0 5-5v-3a5 5 0 0 0-3-5Z"/>',
  filter:'<path d="M5 10h38M12 24h24M20 38h8"/>',
  gift:'<rect x="5" y="20" width="38" height="23" rx="3"/><path d="M3 15h42v10H3ZM24 15v28M24 15c-20 0-13-19 0 0Zm0 0c20 0 13-19 0 0Z"/>',
  faceid:'<path d="M7 17v-4a6 6 0 0 1 6-6h4M31 7h4a6 6 0 0 1 6 6v4M41 31v4a6 6 0 0 1-6 6h-4M17 41h-4a6 6 0 0 1-6-6v-4M17 19v4M31 19v4M24 19v8h-2M17 32c2 3 4 4 7 4s5-1 7-4"/>',
  fingerprint:'<path d="M9 22a15 15 0 0 1 30 0M14 25v6a10 10 0 0 0 6 10M24 14a10 10 0 0 1 10 10v7M24 22v11M29 36l-2 7"/>',
  currency:'<circle cx="24" cy="24" r="19"/><path d="M32 16H20a6 6 0 0 0 0 12h8a6 6 0 0 1 0 12H16M24 8v8m0 24v5"/>',
  apps:'<rect x="6" y="6" width="15" height="15" rx="4.5"/><rect x="27" y="6" width="15" height="15" rx="4.5"/><rect x="6" y="27" width="15" height="15" rx="4.5"/><rect x="27" y="27" width="15" height="15" rx="4.5"/>',
  clock:'<circle cx="24" cy="24" r="19"/><path d="M24 13v12l8 5"/>',
  session:'<circle cx="24" cy="24" r="19"/><path d="M24 13v12l8 5"/>',
  copy:'<rect x="17" y="17" width="26" height="26" rx="6"/><path d="M31 17v-4a6 6 0 0 0-6-6H11a6 6 0 0 0-6 6v14a6 6 0 0 0 6 6h4"/>',
  info:'<circle cx="24" cy="24" r="19"/><path d="M24 22v12M24 15v.5"/>',
  warn:'<path d="M24 6 44 41H4Z"/><path d="M24 19v10M24 35v.5"/>',
  share:'<circle cx="37" cy="10" r="6"/><circle cx="11" cy="24" r="6"/><circle cx="37" cy="38" r="6"/><path d="m16 21 16-8M16 27l16 8"/>',
  trash:'<path d="M6 12h36M17 12V6h14v6M10 12l2 30h24l2-30M20 21v14M28 21v14"/>',
  mail:'<rect x="5" y="9" width="38" height="30" rx="6"/><path d="m6 14 18 14 18-14"/>',
  backspace:'<path d="M17 10h22a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H17L5 24Z"/><path d="m25 19 10 10m0-10L25 29"/>',
  shuffle:'<path d="M5 14h6c9 0 11 20 20 20h8M5 34h6c4 0 7-3 9-7M25 21c2-4 4-7 8-7h6"/><path d="m34 8 6 6-6 6M34 28l6 6-6 6"/>'
};
const SX_STROKE = 3.6;
const _svgCache = new Map();
const _legacyOnly = /<(?:path|circle|rect)\s+class="d2"[^>]*\/>/g;
function svg(name, size){
  size = size || 20;
  const key = name + '|' + size;
  let s = _svgCache.get(key);
  if (s) return s;
  const own = SXI[name];
  /* ancien tracé 24 px : redimensionné x2 au même trait, sans son ombre décalée */
  const body = own ? own : (IC[name] ? '<g transform="scale(2)" stroke-width="' + (SX_STROKE / 2) + '">' + String(IC[name]).replace(_legacyOnly, '') + '</g>' : '');
  s = '<svg viewBox="0 0 48 48" width="' + size + '" height="' + size + '" style="width:calc(' + size + 'px*var(--ui));height:calc(' + size + 'px*var(--ui))" class="ic" fill="none" stroke="currentColor" stroke-width="' + SX_STROKE + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + body + '</svg>';
  _svgCache.set(key, s);
  return s;
}
const icon = (name, size) => svg(name, size);

const FLAGS = {
  OM:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.7" fill="#DB0011"/><rect y="13.3" width="30" height="6.7" fill="#008000"/><rect width="8" height="20" fill="#DB0011"/><path d="M2.5 4L4 6.5 1 6.5z" fill="#fff"/></svg>',
  AE:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.7" fill="#009A44"/><rect y="13.3" width="30" height="6.7" fill="#000"/><rect width="8" height="20" fill="#CE1126"/></svg>',
  SA:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#19375a"/><path d="M7 13h16M7 15h14" stroke="#fff" stroke-width="1.2"/></svg>',
  QA:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><path d="M0 0h8l2 2-2 2 2 2-2 2 2 2-2 2 2 2-2 2 2 2-2 2H0z" fill="#8D1B3D"/></svg>',
  KW:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.7" fill="#007A3D"/><rect y="13.3" width="30" height="6.7" fill="#CE1126"/><path d="M0 0l7 6.7v6.7L0 20z" fill="#000"/></svg>',
  BH:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><path d="M0 0h8l3 2.5-3 2.5 3 2.5-3 2.5 3 2.5-3 2.5H0z" fill="#CE1126"/></svg>',
  US:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><g fill="#B22234"><rect width="30" height="1.54"/><rect y="3.08" width="30" height="1.54"/><rect y="6.16" width="30" height="1.54"/><rect y="9.24" width="30" height="1.54"/><rect y="12.32" width="30" height="1.54"/><rect y="15.4" width="30" height="1.54"/></g><rect width="12" height="10.78" fill="#3C3B6E"/></svg>',
  FR:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="10" height="20" fill="#002395"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#ED2939"/></svg>',
  GB:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#012169"/><path d="M0 0l30 20M30 0L0 20" stroke="#fff" stroke-width="4"/><path d="M15 0v20M0 10h30" stroke="#fff" stroke-width="6"/><path d="M15 0v20M0 10h30" stroke="#C8102E" stroke-width="3.6"/></svg>',
  CI:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="10" height="20" fill="#FF8200"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#009A44"/></svg>',
  ML:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="10" height="20" fill="#14B53A"/><rect x="10" width="10" height="20" fill="#CFE7FF"/><rect x="20" width="10" height="20" fill="#CE1126"/></svg>',
  BF:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="10" fill="#EF2B2D"/><rect y="10" width="30" height="10" fill="#009E49"/></svg>',
  GN:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="10" height="20" fill="#CE1126"/><rect x="10" width="10" height="20" fill="#CFE7FF"/><rect x="20" width="10" height="20" fill="#009460"/></svg>',
  SD:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="6.7" fill="#D21034"/><rect y="6.7" width="30" height="6.6" fill="#fff"/><rect y="13.3" width="30" height="6.7" fill="#000"/><path d="M0 0l8 10-8 10z" fill="#007229"/></svg>',
  EG:'<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="6.7" fill="#CE1126"/><rect y="6.7" width="30" height="6.6" fill="#fff"/><rect y="13.3" width="30" height="6.7" fill="#000"/></svg>'
};
function flag(iso){ return FLAGS[iso] || FLAGS.US; }

const isArabicUi = () => typeof LANG === 'string' && LANG === 'ar';
function logoMark(size){
  size = size || 48;
  return '<img class="logo-mark" src="assets/brand/sanad-s-192.png" alt="' + (isArabicUi() ? 'سند باي' : 'Sanad Pay') + '" width="' + size + '" height="' + size + '" style="width:calc(' + size + 'px*var(--ui));height:calc(' + size + 'px*var(--ui));border-radius:22%" decoding="async">';
}
function logoLockup(size){
  size = size || 48;
  /* arabe : mot-symbole « سند باي » (jamais de lettres espacées : elles casseraient les liaisons de l'écriture arabe) */
  const word = isArabicUi()
    ? '<span class="logo-name logo-name-ar">سند</span><span class="logo-sub logo-sub-ar">باي</span>'
    : '<span class="logo-name">SANAD</span><span class="logo-sub">PAY</span>';
  return '<div class="logo-lockup">' + logoMark(size) + '<div class="logo-word">' + word + '</div></div>';
}
const ASSET_INITIALS = { BTC:'₿', ETH:'Ξ', USDT:'₮', USDC:'$', BNB:'BNB', SOL:'SOL', XRP:'XRP', LTC:'Ł' };
function assetLogo(symbol, size, tint){
  size = size || 40;
  const bg = tint || (CRYPTO_ASSETS.find(a => a.symbol === symbol) || { tint:'#2081c7' }).tint;
  const init = ASSET_INITIALS[symbol] || symbol.slice(0, 2);
  return '<div class="asset-coin" style="width:' + size + 'px;height:' + size + 'px;background:' + bg + '">' + init + '</div>';
}
function networkLogo(net, size){
  size = size || 40;
  const tint = net.tint || '#2081c7';
  const init = (net.symbol || 'N').slice(0, 3);
  return '<div class="net-logo" style="width:' + size + 'px;height:' + size + 'px;background:linear-gradient(135deg,' + tint + ',' + tint + 'cc)">' + init + '</div>';
}

function settingsToggleRow({ icon, title, sub, checked, action, id }){
  return '<button class="settings-row" type="button" data-action="' + action + '" id="' + (id || '') + '" role="switch" aria-checked="' + (checked ? 'true' : 'false') + '">' +
    '<div class="tile">' + icon_(icon, 20) + '</div>' +
    '<div class="settings-row-body"><div class="settings-row-title">' + escapeHtml(title) + '</div>' +
    (sub ? '<div class="settings-row-sub">' + escapeHtml(sub) + '</div>' : '') + '</div>' +
    '<span class="switch" aria-hidden="true"></span>' +
  '</button>';
}
function settingsLinkRow({ icon, title, sub, nav, value }){
  return '<button class="settings-row" type="button" data-nav="' + nav + '">' +
    '<div class="tile">' + icon_(icon, 20) + '</div>' +
    '<div class="settings-row-body"><div class="settings-row-title">' + escapeHtml(title) + '</div>' +
    (sub ? '<div class="settings-row-sub">' + escapeHtml(sub) + '</div>' : '') + '</div>' +
    (value ? '<span class="settings-value">' + escapeHtml(value) + '</span>' : '') +
    '<span class="settings-row-chev">' + icon_('chev', 18) + '</span>' +
  '</button>';
}
function settingsSection(title){
  return '<div class="settings-section">' + escapeHtml(title) + '</div>';
}
function icon_(name, size){ return svg(name, size); }

/* YOR icon set v6: 24px grid, 1.8 stroke, rounded caps, soft duotone fill */
const YOR_ICONS = (() => {
  const duo = (d) => '<path d="' + d + '" fill="currentColor" fill-opacity=".15" stroke="none"/><path d="' + d + '"/>';
  const dc = (cx, cy, r) => '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="currentColor" fill-opacity=".15" stroke="none"/><circle cx="' + cx + '" cy="' + cy + '" r="' + r + '"/>';
  const rr = (x, y, w, h, r) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r + '" fill="currentColor" fill-opacity=".15" stroke="none"/><rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r + '"/>';
  return {
    home: duo('M4 10.6 12 4l8 6.6V19a1.5 1.5 0 0 1-1.5 1.5H15v-5.2H9v5.2H5.5A1.5 1.5 0 0 1 4 19z'),
    history: dc(12, 12, 8.5) + '<path d="M12 7.6V12l3 1.9"/>',
    send: duo('M20.5 3.5 3.5 10l6.4 3.8 3.8 6.7z') + '<path d="M20.5 3.5 9.9 13.8"/>',
    receive: '<path d="M12 4v11M7.4 10.6 12 15.2l4.6-4.6"/><path d="M5 19.5h14"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    check: '<path d="M5 12.5l4.6 4.6L19 7.5"/>',
    chev: '<path d="M9.5 6l6 6-6 6"/>',
    back: '<path d="M14.5 6l-6 6 6 6"/>',
    user: dc(12, 8.4, 3.8) + '<path d="M4.6 20c.9-3.7 3.8-5.6 7.4-5.6s6.5 1.9 7.4 5.6"/>',
    profile: dc(12, 8.4, 3.8) + '<path d="M4.6 20c.9-3.7 3.8-5.6 7.4-5.6s6.5 1.9 7.4 5.6"/>',
    wallet: rr(3.5, 6.5, 17, 13, 3.2) + '<path d="M6.5 6.5 15 4a1.5 1.5 0 0 1 1.9 1.4v1.1"/><path d="M15.5 13h2.2"/>',
    globe: dc(12, 12, 8.5) + '<path d="M3.5 12h17M12 3.5c2.4 2.4 3.4 5.2 3.4 8.5s-1 6.1-3.4 8.5c-2.4-2.4-3.4-5.2-3.4-8.5s1-6.1 3.4-8.5z"/>',
    cards: rr(2.8, 5.2, 18.4, 13.6, 3) + '<path d="M2.8 10h18.4M6.5 15h3"/>',
    crypto: dc(12, 12, 8.5) + '<path d="M9.6 8.4h3.1a1.9 1.9 0 0 1 0 3.8H9.6m0 0h3.5a1.9 1.9 0 0 1 0 3.8H9.6M9.6 8.4V16M11.6 7v1.4M11.6 16v1.4"/>',
    mobile: rr(7, 2.8, 10, 18.4, 2.6) + '<path d="M11 17.6h2"/>',
    settings: dc(12, 12, 3.1) + '<path d="M12 3v2.4M12 18.6V21M3 12h2.4M18.6 12H21M5.6 5.6l1.7 1.7M16.7 16.7l1.7 1.7M5.6 18.4l1.7-1.7M16.7 7.3l1.7-1.7"/>',
    lock: rr(5, 10.5, 14, 10, 2.8) + '<path d="M8.2 10.5V7.8a3.8 3.8 0 0 1 7.6 0v2.7M12 14.6v2.2"/>',
    shield: duo('M12 3.2 19.5 6v5.6c0 4.4-3 7.6-7.5 9.2-4.5-1.6-7.5-4.8-7.5-9.2V6z') + '<path d="M8.9 12.1l2.2 2.2 4-4.2"/>',
    eye: '<path d="M2.6 12S6 5.6 12 5.6 21.4 12 21.4 12 18 18.4 12 18.4 2.6 12 2.6 12z"/>' + dc(12, 12, 2.9),
    eyeOff: '<path d="M10.6 5.8A9.3 9.3 0 0 1 12 5.6c6 0 9.4 6.4 9.4 6.4a16 16 0 0 1-2.7 3.5M6.6 7.3A15.600 15.600 0 0 0 2.6 12S6 18.4 12 18.4a9 9 0 0 0 4.200-1"/><path d="M9.9 9.9a3 3 0 0 0 4.200 4.200M3.5 3.5l17 17"/>',
    bell: duo('M6 9.5a6 6 0 0 1 12 0c0 5.400 2 6.800 2 6.800H4S6 14.900 6 9.500z') + '<path d="M10 19.800a2.200 2.200 0 0 0 4 0"/>',
    chart: '<path d="M4 4v16h16"/><path d="M8 15l3.400-3.800 3 2.600L19 8.200"/>',
    trending: '<path d="M3.500 17l6-6 4 4L21 7.500"/><path d="M15.500 7.500H21V13"/>',
    share: dc(6, 12, 2.6) + dc(17.400, 5.800, 2.600) + dc(17.400, 18.200, 2.600) + '<path d="M8.300 10.800l6.800-3.800M8.300 13.200l6.800 3.800"/>',
    download: '<path d="M12 4v11M7.400 10.800 12 15.400l4.600-4.600"/><path d="M5 19.500h14"/>',
    copy: rr(8.500, 8.500, 11.500, 11.500, 2.600) + '<path d="M15.500 8.500V6.400a2 2 0 0 0-2-2H6.400a2 2 0 0 0-2 2v7.100a2 2 0 0 0 2 2h2.100"/>',
    cal: rr(3.500, 5, 17, 15.500, 3) + '<path d="M3.500 10h17M8 3v4M16 3v4"/>',
    clock: dc(12, 12, 8.500) + '<path d="M12 7.600V12l3 1.900"/>',
    doc: duo('M14 3H7.500A2.500 2.500 0 0 0 5 5.500v13A2.500 2.500 0 0 0 7.500 21h9a2.500 2.500 0 0 0 2.500-2.500V8z') + '<path d="M14 3v5h5M8.800 13h6.400M8.800 16.500h4"/>',
    percent: '<path d="M18.500 5.500l-13 13"/>' + dc(7, 7, 2.300) + dc(17, 17, 2.300),
    logout: '<path d="M9.500 20.500H6.500a2.500 2.500 0 0 1-2.500-2.500V6a2.500 2.500 0 0 1 2.500-2.500h3"/><path d="M15.500 16.500 20 12l-4.500-4.500M20 12H9.500"/>',
    warn: duo('M12 3.800 21 19.500H3z') + '<path d="M12 10v4M12 16.800h.01"/>',
    search: dc(11, 11, 6.800) + '<path d="M20 20l-4-4"/>',
    swap: '<path d="M7.500 4.500v14M7.500 4.500l-3.200 3.200M7.500 4.500l3.200 3.200M16.500 19.500v-14M16.500 19.500l-3.200-3.200M16.500 19.500l3.200-3.200"/>',
    bank: duo('M3.500 9.500 12 4l8.500 5.500z') + '<path d="M5.500 10v7.500M9.800 10v7.500M14.200 10v7.500M18.500 10v7.500M3.500 20.500h17"/>',
    banknote: rr(2.500, 6, 19, 12, 2.600) + dc(12, 12, 2.600),
    qr: rr(3.500, 3.500, 6.500, 6.500, 1.400) + rr(14, 3.500, 6.500, 6.500, 1.400) + rr(3.500, 14, 6.500, 6.500, 1.400) + '<path d="M14 14h3v3M20.500 14v.1M14 20.500h3.500M20.500 17.500v3"/>',
    network: dc(12, 12, 2.800) + dc(5, 5.500, 1.900) + dc(19, 5.500, 1.900) + dc(5, 18.500, 1.900) + dc(19, 18.500, 1.900) + '<path d="M6.400 6.800l3.400 3.400M17.600 6.800l-3.400 3.400M6.400 17.200l3.400-3.400M17.600 17.200l-3.400-3.400"/>',
    arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    arrowUpRight: '<path d="M7 17 17 7M8.500 7H17v8.500"/>',
    arrowDownRight: '<path d="M7 7l10 10M17 8.500V17H8.500"/>',
    sparkle: duo('M12 3l1.900 5.600L19.500 10.500l-5.600 1.900L12 18l-1.900-5.600L4.500 10.500l5.600-1.900z') + '<path d="M19 3v3M17.500 4.500h3"/>',
    trash: '<path d="M4 6.500h16M9.500 6.500V4.500h5v2M6.500 6.500l.9 12.600a2 2 0 0 0 2 1.900h5.200a2 2 0 0 0 2-1.900l.9-12.600M10 11v5.500M14 11v5.500"/>',
    info: dc(12, 12, 8.500) + '<path d="M12 11v5M12 7.900h.01"/>',
    mail: rr(3, 5.500, 18, 13, 2.800) + '<path d="M3.500 8l8.500 6 8.500-6"/>',
    help: dc(12, 12, 8.500) + '<path d="M9.600 9.600a2.500 2.500 0 1 1 3.600 2.200c-.8.400-1.200.9-1.200 1.800M12 16.800h.01"/>',
    vibrate: rr(8, 3, 8, 18, 2.400) + '<path d="M3.500 8.500v7M20.500 8.500v7M11 17.800h2"/>',
    contact: dc(10.500, 8.600, 3.600) + '<path d="M3.600 20c.8-3.400 3.400-5.300 6.900-5.300s6.100 1.900 6.900 5.300M19 6.500v5M16.500 9h5"/>',
    device: rr(6.500, 2.800, 11, 18.400, 2.800) + '<path d="M10.500 17.800h3"/>',
    session: dc(12, 12, 8.500) + '<path d="M12 7.600V12l3 1.900"/>'
  };
})();

Object.assign(IC, YOR_ICONS);

/* ============================================================
   FRIENDLY ICON SET (12.9.0) — new drawings, 24px grid, 1.9 stroke, round caps.
   Signature: every filled icon has a soft "shadow" shape (class d2) offset by 1.4px behind the line drawing, tinted by --ic2
   (falls back to currentColor). The shadow snaps into place on press and "pops" on the active tab (css/friendly.css).
   The eye is line-only on purpose (transparent). Names are unchanged from the previous set, plus apps / faceid / backspace / shuffle.
   ============================================================ */
const FRIENDLY_ICONS = (() => {
  const s2 = (d) => '<path class="d2" d="' + d + '"/>';
  const c2 = (cx, cy, r) => '<circle class="d2" cx="' + cx + '" cy="' + cy + '" r="' + r + '"/>';
  const r2 = (x, y, w, h, r) => '<rect class="d2" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r + '"/>';
  const p = (d) => '<path d="' + d + '"/>';
  const c = (cx, cy, r) => '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '"/>';
  const r = (x, y, w, h, rx) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + rx + '"/>';
  const person = c2(12, 8.2, 3.6) + c(12, 8.2, 3.6) + p('M4.8 20.2c.8-3.8 3.7-5.7 7.2-5.7s6.4 1.9 7.2 5.7');
  const clock = c2(12, 12, 8.3) + c(12, 12, 8.3) + p('M12 7.6V12l3.1 1.9');
  return {
    home: s2('M5.6 10.2 12 4.8l6.4 5.4V19a1.5 1.5 0 0 1-1.5 1.5H7.1A1.5 1.5 0 0 1 5.6 19z') + p('M3.4 11.4 12 4l8.6 7.4') + p('M5.6 9.9V19a1.5 1.5 0 0 0 1.5 1.5h9.8a1.5 1.5 0 0 0 1.5-1.5V9.9') + p('M10 20.5v-4.6a2 2 0 0 1 4 0v4.6'),
    cards: r2(3, 5.5, 18, 13, 3.4) + r(3, 5.5, 18, 13, 3.4) + p('M3 10.2h18') + p('M7 15.2h3.4'),
    send: s2('M20.6 3.4 14 20.6l-3.6-7L3.4 10z') + p('M20.6 3.4 14 20.6l-3.6-7L3.4 10z') + p('M20.6 3.4 10.4 13.6'),
    crypto: s2('M12 3.4l7.4 4.2v8.8L12 20.6l-7.4-4.2V7.6z') + p('M12 3.4l7.4 4.2v8.8L12 20.6l-7.4-4.2V7.6z') + p('M12 8.3l3.2 3.7-3.2 3.7-3.2-3.7z'),
    apps: r2(4, 4, 6.4, 6.4, 2) + r2(13.6, 4, 6.4, 6.4, 2) + r2(4, 13.6, 6.4, 6.4, 2) + r2(13.6, 13.6, 6.4, 6.4, 2) + r(4, 4, 6.4, 6.4, 2) + r(13.6, 4, 6.4, 6.4, 2) + r(4, 13.6, 6.4, 6.4, 2) + r(13.6, 13.6, 6.4, 6.4, 2),
    history: c2(12.4, 12.4, 7.6) + p('M12.4 4.4a8 8 0 1 1-7.7 5.8') + p('M4.2 4.6v4.2h4.2') + p('M12.4 8.2v4.2l2.9 1.8'),
    receive: r2(4.5, 16.6, 15, 3.8, 1.9) + p('M12 3.8v11M7.5 10.6 12 15.1l4.5-4.5') + p('M4.5 19.4h15'),
    plus: p('M12 5v14M5 12h14'),
    minus: p('M5 12h14'),
    close: p('M6.5 6.5l11 11M17.5 6.5l-11 11'),
    check: p('M5 12.6l4.7 4.6L19 7.6'),
    chev: p('M9.5 5.8l6.2 6.2-6.2 6.2'),
    back: p('M14.5 5.8 8.3 12l6.2 6.2'),
    user: person,
    profile: person,
    wallet: r2(3.4, 6.6, 17.2, 13, 3.6) + r(3.4, 6.6, 17.2, 13, 3.6) + p('M6.6 6.6l9.6-3a1.4 1.4 0 0 1 1.8 1.3v1.7') + p('M14.6 13.1h3.8'),
    globe: c2(12, 12, 8.4) + c(12, 12, 8.4) + p('M3.6 12h16.8') + p('M12 3.6c2.4 2.4 3.4 5.2 3.4 8.4s-1 6-3.4 8.4c-2.4-2.4-3.4-5.2-3.4-8.4s1-6 3.4-8.4z'),
    mobile: r2(6.8, 2.8, 10.4, 18.4, 3) + r(6.8, 2.8, 10.4, 18.4, 3) + p('M10.6 17.8h2.8'),
    device: r2(6.8, 2.8, 10.4, 18.4, 3) + r(6.8, 2.8, 10.4, 18.4, 3) + p('M10.6 17.8h2.8'),
    settings: p('M4 7h8.6M17.6 7H20M4 12h2.6M11.6 12H20M4 17h8.9M17.9 17H20') + c2(15.1, 7, 2.5) + c(15.1, 7, 2.5) + c2(9.1, 12, 2.5) + c(9.1, 12, 2.5) + c2(15.4, 17, 2.5) + c(15.4, 17, 2.5),
    lock: r2(5, 10.4, 14, 10.2, 3) + r(5, 10.4, 14, 10.2, 3) + p('M8.2 10.4V7.9a3.8 3.8 0 0 1 7.6 0v2.5') + p('M12 14.7v2.4'),
    shield: s2('M12 3.4 19.6 6.2v5.5c0 4.3-3 7.5-7.6 9.1-4.6-1.6-7.6-4.8-7.6-9.1V6.2z') + p('M12 3.4 19.6 6.2v5.5c0 4.3-3 7.5-7.6 9.1-4.6-1.6-7.6-4.8-7.6-9.1V6.2z') + p('M8.9 12l2.2 2.2 4.1-4.3'),
    eye: p('M2.6 12S6 5.8 12 5.8 21.4 12 21.4 12 18 18.2 12 18.2 2.6 12 2.6 12z') + c(12, 12, 2.9),
    eyeOff: p('M10.4 5.9A8.6 8.6 0 0 1 12 5.8c6 0 9.4 6.2 9.4 6.2a16 16 0 0 1-3 3.7M6.5 7.6A15.600 15.600 0 0 0 2.6 12S6 18.2 12 18.2a9 9 0 0 0 4-.9') + p('M9.8 9.9a3 3 0 0 0 4.200 4.200') + p('M4 4l16 16'),
    bell: s2('M12 4a5.700 5.700 0 0 0-5.700 5.700v4L4.500 16.800v.7h15v-.7l-1.800-3.100v-4A5.700 5.700 0 0 0 12 4z') + p('M12 4a5.700 5.700 0 0 0-5.700 5.700v4L4.500 16.800v.7h15v-.7l-1.800-3.100v-4A5.700 5.700 0 0 0 12 4z') + p('M9.800 20.300a2.400 2.400 0 0 0 4.400 0'),
    chart: p('M6 20v-6M12 20V5.500M18 20v-9.500'),
    trending: p('M3.500 16.500l5.500-5.500 4 4 7.500-8') + p('M15 7h5.500v5.500'),
    share: c2(6.200, 12, 2.600) + c2(17.400, 5.800, 2.600) + c2(17.400, 18.200, 2.600) + c(6.200, 12, 2.600) + c(17.400, 5.800, 2.600) + c(17.400, 18.200, 2.600) + p('M8.500 10.800l6.600-3.800M8.500 13.200l6.600 3.800'),
    download: p('M12 4v11M7.500 10.600 12 15.100l4.500-4.500') + p('M4.500 19.500h15'),
    copy: r2(8.800, 8.800, 11.200, 11.200, 3) + r(8.800, 8.800, 11.200, 11.200, 3) + p('M15.500 8.800V6.700a2.200 2.200 0 0 0-2.200-2.200H6.700a2.200 2.200 0 0 0-2.200 2.200v6.600a2.200 2.200 0 0 0 2.200 2.200h2.100'),
    cal: r2(3.500, 5, 17, 15.500, 3.400) + r(3.500, 5, 17, 15.500, 3.400) + p('M3.500 10h17M8 3v4M16 3v4'),
    clock: clock,
    session: clock,
    doc: s2('M14 3.600H7.600A2.600 2.600 0 0 0 5 6.200v11.600A2.600 2.600 0 0 0 7.600 20.400h8.800A2.600 2.600 0 0 0 19 17.800V8.600z') + p('M14 3.600H7.600A2.600 2.600 0 0 0 5 6.200v11.600A2.600 2.600 0 0 0 7.600 20.400h8.800A2.600 2.600 0 0 0 19 17.800V8.600z') + p('M13.800 3.800v4.800h4.900M8.800 13h6.400M8.800 16.500h4'),
    percent: p('M18.500 5.500l-13 13') + c2(7.200, 7.200, 2.400) + c(7.200, 7.200, 2.400) + c2(16.800, 16.800, 2.400) + c(16.800, 16.800, 2.400),
    logout: p('M9.500 20.500H6.800A2.800 2.800 0 0 1 4 17.700V6.300a2.800 2.800 0 0 1 2.800-2.800h2.700') + p('M15.500 16.500 20 12l-4.500-4.500M20 12H9.500'),
    warn: s2('M12 3.800 21.200 19.800H2.800z') + p('M12 3.800 21.200 19.800H2.800z') + p('M12 10v4.200M12 16.900h.01'),
    search: c2(11, 11, 6.800) + c(11, 11, 6.800) + p('M20 20l-4.200-4.200'),
    swap: p('M5 8.500h12.500M14.500 5.500l3 3-3 3') + p('M19 15.500H6.500M9.500 12.500l-3 3 3 3'),
    bank: s2('M3.500 9.600 12 4l8.500 5.600z') + p('M3.500 9.600 12 4l8.500 5.600z') + p('M5.800 12.600v4.800M10 12.600v4.800M14 12.600v4.800M18.200 12.600v4.800M3.500 20.500h17'),
    banknote: r2(2.500, 6, 19, 12, 3) + r(2.500, 6, 19, 12, 3) + c(12, 12, 2.600),
    qr: r2(3.500, 3.500, 6.500, 6.500, 1.600) + r(3.500, 3.500, 6.500, 6.500, 1.600) + r(14, 3.500, 6.500, 6.500, 1.600) + r(3.500, 14, 6.500, 6.500, 1.600) + p('M14 14h3v3M20.500 14v.1M14 20.500h3.500M20.500 17.500v3'),
    network: c2(12, 12, 2.800) + c(12, 12, 2.800) + c(5, 5.500, 1.900) + c(19, 5.500, 1.900) + c(5, 18.500, 1.900) + c(19, 18.500, 1.900) + p('M6.400 6.800l3.400 3.400M17.600 6.800l-3.400 3.400M6.400 17.200l3.400-3.400M17.600 17.200l-3.400-3.400'),
    arrowRight: p('M5 12h14M13 6l6 6-6 6'),
    arrowUpRight: p('M7 17 17 7M8.500 7H17v8.500'),
    arrowDownRight: p('M7 7l10 10M17 8.500V17H8.500'),
    sparkle: s2('M12 3.800c.7 4.100 2.300 5.700 6.400 6.400-4.100.7-5.700 2.300-6.400 6.400-.7-4.100-2.300-5.700-6.400-6.400 4.100-.7 5.700-2.300 6.400-6.400z') + p('M12 3.800c.7 4.100 2.300 5.700 6.400 6.400-4.100.7-5.700 2.300-6.400 6.400-.7-4.100-2.300-5.700-6.400-6.400 4.100-.7 5.700-2.300 6.400-6.400z') + p('M18.500 15.500v4M16.500 17.500h4'),
    trash: s2('M6.500 7.500h11l-.8 11.400a2 2 0 0 1-2 1.800H9.300a2 2 0 0 1-2-1.800z') + p('M4 6.500h16M9.500 6.500V4.500h5v2M6.600 7.500l.7 11.400a2 2 0 0 0 2 1.800h5.400a2 2 0 0 0 2-1.800l.7-11.400M10 11v5.500M14 11v5.500'),
    info: c2(12, 12, 8.400) + c(12, 12, 8.400) + p('M12 11v5M12 7.900h.01'),
    mail: r2(3, 5.500, 18, 13, 3.200) + r(3, 5.500, 18, 13, 3.200) + p('M3.800 8.200 12 14l8.200-5.800'),
    help: c2(12, 12, 8.400) + c(12, 12, 8.400) + p('M9.600 9.600a2.500 2.500 0 1 1 3.600 2.200c-.8.400-1.200.9-1.200 1.800M12 16.800h.01'),
    vibrate: r2(8, 3, 8, 18, 2.600) + r(8, 3, 8, 18, 2.600) + p('M3.500 8.500v7M20.500 8.500v7M11 17.800h2'),
    contact: c2(10.500, 8.600, 3.600) + c(10.500, 8.600, 3.600) + p('M3.600 20c.8-3.400 3.400-5.300 6.900-5.300s6.100 1.900 6.900 5.300M19 6.500v5M16.500 9h5'),
    backspace: s2('M9.200 5.600h9.300a1.600 1.600 0 0 1 1.600 1.600v9.600a1.600 1.600 0 0 1-1.600 1.600H9.200L3.600 12z') + p('M9.200 5.600h9.300a1.600 1.600 0 0 1 1.600 1.600v9.600a1.600 1.600 0 0 1-1.600 1.600H9.200L3.600 12z') + p('M12.800 9.600l4.200 4.800M17 9.600l-4.200 4.800'),
    shuffle: p('M3.500 7.500h3c4.200 0 5 9 9.200 9h3.800M3.500 16.500h3c1.700 0 2.800-1.300 3.700-3M13.500 10.300c.9-1.700 2-2.800 3.700-2.800h2.300') + p('M17.500 5l2.500 2.500-2.500 2.500M17.500 14l2.500 2.500-2.500 2.500'),
    faceid: p('M4 8.200V6.600A2.600 2.600 0 0 1 6.600 4H8.200M15.800 4h1.600A2.600 2.600 0 0 1 20 6.600v1.600M20 15.800v1.600a2.600 2.600 0 0 1-2.600 2.600h-1.600M8.200 20H6.600A2.600 2.600 0 0 1 4 17.400v-1.600') + p('M9.200 9.600v1.600M14.800 9.600v1.600M12 9.600v3.700h-.8M9.200 15.600c.8 1 1.700 1.500 2.800 1.500s2-.5 2.800-1.500')
  };
})();
Object.assign(IC, FRIENDLY_ICONS);

/* 16.0.0 : icônes ajoutées (récompense, sons, adresse, clé, actualiser, administration) — même grille 24 px, trait 1,8 */
const LX_ICONS = (() => {
  const s2 = (d) => '<path class="d2" d="' + d + '"/>';
  const p = (d) => '<path d="' + d + '"/>';
  const c = (cx, cy, r) => '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '"/>';
  const r2 = (x, y, w, h, r) => '<rect class="d2" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r + '"/>';
  const r = (x, y, w, h, rx) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + rx + '"/>';
  return {
    gift: r2(4, 9.5, 16, 10.5, 2.4) + r(4, 9.5, 16, 10.5, 2.4) + p('M12 9.5V20M3.2 9.5h17.6v3.3H3.2z') + p('M12 9.5C10.4 5 6 5.6 7 8.4c.3.9 2.2 1.1 5 1.1zM12 9.5c1.6-4.5 6-3.9 5-1.1-.3.9-2.2 1.1-5 1.1z'),
    volume: p('M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z') + p('M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11'),
    volumeOff: p('M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z') + p('M16 9.5l5 5M21 9.5l-5 5'),
    map: s2('M12 21s6.5-5.8 6.5-11A6.5 6.5 0 0 0 5.5 10c0 5.2 6.5 11 6.5 11z') + p('M12 21s6.5-5.8 6.5-11A6.5 6.5 0 0 0 5.5 10c0 5.2 6.5 11 6.5 11z') + c(12, 10, 2.4),
    key: c(8, 14, 3.8) + p('M10.8 11.3 20 2.5M16.5 6l2.5 2.5M14 8.5l2 2'),
    refresh: p('M4.5 12a7.5 7.5 0 0 1 13-5M19.5 4v4h-4M19.5 12a7.5 7.5 0 0 1-13 5M4.5 20v-4h4'),
    users: c(9, 8.5, 3.4) + p('M2.8 19.5c.7-3.4 3-5 6.2-5s5.500 1.600 6.200 5') + c(17, 9.500, 2.500) + p('M17.500 14.500c2.200.2 3.700 1.600 4.200 4'),
    admin: s2('M12 3.4 19.6 6.2v5.5c0 4.3-3 7.5-7.6 9.1-4.6-1.6-7.6-4.8-7.6-9.1V6.2z') + p('M12 3.4 19.6 6.2v5.5c0 4.3-3 7.5-7.6 9.1-4.6-1.6-7.6-4.8-7.6-9.1V6.2z') + p('M12 8.200v4.400M12 15h.01'),
    trophy: p('M8 4h8v5a4 4 0 0 1-8 0zM8 6H5v1.500A3 3 0 0 0 8 10.500M16 6h3v1.500a3 3 0 0 1-3 3M12 13v4M8.500 20h7M10 17h4'),
  };
})();
Object.assign(IC, LX_ICONS);
