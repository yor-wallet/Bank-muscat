REEW WALLET — READY PACKAGE

Structure
---------
index.html
icon.svg
manifest.json
favicon.ico
assets/
  favicon-32.png
  apple-touch-icon.png
  icon-192.png
  icon-512.png
  logo-original.png

The supplied index.html is preserved as the application source.
The application already contains its UI icons as inline SVG, so no icon library
or external CDN is required for the existing interface.

The PNG assets are provided for browser/PWA/iOS compatibility.
